#ifndef GLOBEVIEW_H
#define GLOBEVIEW_H
#include "globe.h"


class GlobeView
{
public:
    GlobeView(float radius, unsigned long mode1,unsigned long mode2, float red, float yellow, float blue);
    void Draw();
private:
    Globe* globe;

};

#endif // GLOBEVIEW_H
