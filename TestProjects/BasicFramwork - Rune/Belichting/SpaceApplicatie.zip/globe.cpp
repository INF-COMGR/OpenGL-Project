#include "globe.h"

Globe::Globe(float radius, unsigned long mode1,unsigned long mode2, float red, float yellow, float blue)
{
    this->radius = radius;
    this->mode1 = mode1;
    this->mode2 = mode2;

    this->red = red;
    this->yellow = yellow;
    this->blue = blue;
}

float Globe::getRadius() {
    return this->radius;
}

unsigned long Globe::getMode1() {
    return this->mode1;
}
unsigned long Globe::getMode2() {
    return this->mode2;
}

float Globe::getRed() {
    return this->red;
}
float Globe::getYellow() {
    return this->yellow;
}
float Globe::getBlue() {
    return this->blue;
}
