#include "globeview.h"
#include <QOpenGLWidget>
#include "util.h"

GlobeView::GlobeView(float radius, unsigned long mode1,unsigned long mode2, float red, float yellow, float blue)
{
    globe = new Globe(radius, mode1, mode2, red, yellow, blue);
}

void GlobeView::Draw() {
    // draw the second planet
    GLfloat color [] = {globe->getRed(), globe->getYellow(), globe->getBlue()};

    glMaterialfv ( globe->getMode1(), globe->getMode2(), color);

    Util::drawSolidSphere(globe->getRadius(), 50, 50);
}
