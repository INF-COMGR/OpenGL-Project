#include "space.h"

Space::Space()
{

}
