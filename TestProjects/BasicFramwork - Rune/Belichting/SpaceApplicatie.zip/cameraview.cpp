#include "cameraview.h"
#include "util.h"
#include <QVector2D>
CameraView::CameraView()  {
    camera = new Camera();
    /*timer = new QTimer();
    connect( timer, SIGNAL(timeout()), this, SLOT(update()) );

    setFocusPolicy(Qt::StrongFocus);

    camPosx = 3.0,  camPosy = 5.0,    camPosz = 25.0;
    camViewx = 0.0, camViewy = 0.0, camViewz = 0.0;
    camUpx = 0.0,   camUpy = 1.0,   camUpz = 0.0;*/
}

/*void CameraView::initializeGL () {
    QOpenGLWidget::initializeGL();

    glShadeModel(GL_SMOOTH);

    // Black canvasf
    glClearColor(0.0f,0.0f,0.0f,0.0f);

    // Place light
    glEnable( GL_LIGHTING );
    glEnable( GL_LIGHT0 );
    glEnable(GL_DEPTH_TEST);

    GLfloat light0_position [] = {0.1f, 0.1f, 0.1f, 0.1f};
    GLfloat light_diffuse []= { 1.0, 1.0, 1.0, 1.0 };
    glLightfv ( GL_LIGHT0, GL_POSITION, light0_position );
    glLightfv ( GL_LIGHT0, GL_DIFFUSE, light_diffuse );

    timer->start(50);
}
void CameraView::resizeGL ( int width, int height ) {
    if ((width<=0) || (height<=0))
        return;

    //set viewport
    glViewport(0,0,width,height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    //set persepective
    //change the next line order to have a different perspective
    GLdouble aspect_ratio=(GLdouble)width/(GLdouble)height;
    gluPerspective(40.0, aspect_ratio, 1.0, 100.0);


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void CameraView::paintGL () {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();

    // store current matrix
    glMatrixMode( GL_MODELVIEW );
    glPushMatrix( );

    gluLookAt(camPosx ,camPosy ,camPosz,
              camViewx,camViewy,camViewz,
              camUpx, camUpy, camUpz );

    //Draw Axes
    glDisable( GL_LIGHTING );
    glBegin(GL_LINES);
        glColor3f(1.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(10.0, 0.0, 0.0);
        glColor3f(0.0, 1.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 10.0, 0.0);
        glColor3f(0.0, 0.0, 1.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 10.0);
    glEnd();
    glEnable( GL_LIGHTING );

    // restore current matrix
    glMatrixMode( GL_MODELVIEW );
    glPopMatrix( );
}*/

void CameraView::Draw() {
    gluLookAt( camera->getPosX(), camera->getPosY(), camera->getPosZ(),
               camera->getPosX() + camera->getViewX(),  camera->getPosY() + camera->getViewY(), camera->getPosZ() + camera->getViewZ(),
               camera->getUpX(), camera->getUpY(), camera->getUpZ()
                );
                //camPosx ,camPosy ,camPosz,
              //camViewx,camViewy,camViewz,
              //camUpx, camUpy, camUpz );

    //Draw Axes
    glDisable( GL_LIGHTING );
    glBegin(GL_LINES);
        glColor3f(1.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(10.0, 0.0, 0.0);
        glColor3f(0.0, 1.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 10.0, 0.0);
        glColor3f(0.0, 0.0, 1.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 10.0);
    glEnd();
    glEnable( GL_LIGHTING );
}

void CameraView::keyPressEvent(QKeyEvent * e) {
    if(e->key() == Qt::Key_Up)
        camera->moveForward();
        //camera->addPosY(0.5); //this->camPosy += 0.5;
    if(e->key() == Qt::Key_Down)
        camera->moveBackward();
        //camera->addPosY(-0.5); //this->camPosy -= 0.5;
    if(e->key() == Qt::Key_Left)
        camera->Left();
        //camera->addPosX(-0.5); //this->camPosx -= 0.5;
    if(e->key() == Qt::Key_Right)
        camera->Right();
        //camera->addPosX(0.5); //this->camPosx += 0.5;

    if(e->key() == Qt::Key_Z)
        camera->addUpY(0.5); //this->camUpy += 0.5;
    if(e->key() == Qt::Key_S)
        camera->addUpY(-0.5); //this->camUpy -= 0.5;
    if(e->key() == Qt::Key_Q)
        camera->addUpX(-0.5); //this->camUpx -= 0.5;
    if(e->key() == Qt::Key_D)
        camera->addUpX(0.5); //this->camUpx += 0.5;
}

void CameraView::mouseMouveEvent(QMouseEvent* e) {
    QVector2D mouse = {(float) e->x(), (float) e->y()};
    camera->mouseUpdate(mouse);
}
