#ifndef GLOBE_H
#define GLOBE_H

class Globe
{
public:
    Globe(float radius, unsigned long mode1,unsigned long mode2, float red, float yellow, float blue);
    float getRadius();
    unsigned long getMode1();
    unsigned long getMode2();
    float getRed();
    float getYellow();
    float getBlue();

private:
    float radius;
    unsigned long mode1;
    unsigned long mode2;
    float red;
    float yellow;
    float blue;


};

#endif // GLOBE_H
