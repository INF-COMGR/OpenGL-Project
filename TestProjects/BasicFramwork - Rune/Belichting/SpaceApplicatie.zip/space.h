#ifndef SPACE_H
#define SPACE_H

class Space
{
public:
    Space();

private:

};


#endif // SPACE_H
